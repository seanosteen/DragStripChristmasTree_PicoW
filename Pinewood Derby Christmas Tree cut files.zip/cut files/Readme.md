# Notes
* Lasercut files are based upon 1/8" (3mm) plywood. Adjustments for kerf may be required for other materials (or, perhaps gentle persuasion with a mallet).
* If frosted acrylic is not available for the light panels, clear acrylic can be "frosted" by using a 200-grit sandpaper to thoroughly scuff the back of the acrylic.